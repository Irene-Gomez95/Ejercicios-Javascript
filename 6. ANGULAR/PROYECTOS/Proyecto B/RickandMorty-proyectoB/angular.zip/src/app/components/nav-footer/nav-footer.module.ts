import { NavFooterComponent } from './nav-footer.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';



@NgModule({
  declarations: [
    NavFooterComponent,
  ],
  imports: [
    CommonModule,
  ],
  exports: [
      NavFooterComponent
  ]
})
export class NavFooterModule { }
