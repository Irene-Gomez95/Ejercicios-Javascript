import { AppRoutingModule } from './../../app-routing.module';
import { HomeHeaderComponent } from './home-header.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';



@NgModule({
  declarations: [
    HomeHeaderComponent,
  ],
  imports: [
    CommonModule,
    AppRoutingModule,
  ],
  exports: [
      HomeHeaderComponent
  ]
})
export class HomeHeaderModule { }
