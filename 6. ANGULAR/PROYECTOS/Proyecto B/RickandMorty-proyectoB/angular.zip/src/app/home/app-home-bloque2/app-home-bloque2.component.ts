import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-home-bloque2',
  templateUrl: './app-home-bloque2.component.html',
  styleUrls: ['./app-home-bloque2.component.scss']
})
export class AppHomeBloque2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
