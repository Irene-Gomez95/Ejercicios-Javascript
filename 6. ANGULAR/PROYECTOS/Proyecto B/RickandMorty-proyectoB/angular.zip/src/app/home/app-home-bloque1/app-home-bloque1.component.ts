import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-home-bloque1',
  templateUrl: './app-home-bloque1.component.html',
  styleUrls: ['./app-home-bloque1.component.scss']
})
export class AppHomeBloque1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
