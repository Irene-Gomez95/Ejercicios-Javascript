import { CharacterService } from './../Services/Services/character.service';
import { Component, OnInit, OnChanges, OnDestroy, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit, OnChanges, OnDestroy {
  public Characterlist: any;

 

  constructor( private CharacterService: CharacterService) { 
    console.log("Me he construido");
  }

  /* Funcion de llamada a la API */
  getCharacters(): void {
this.CharacterService.getcharacters()
    /* subscribe indica que espero respuesta */
    /* 1- la primera función sirve para esperar la respuesta */
      .subscribe((Response: any) => {this.Characterlist  = Response});
      /*  */
    ;
  }

  ngOnInit(): void { 
    this.getCharacters();
    console.log("Me he iniciado");
  }

  ngOnChanges(): void {
      console.log("He cambiado")
  }

  ngOnDestroy(): void {
      console.log("Me he destruido")
  }



}
