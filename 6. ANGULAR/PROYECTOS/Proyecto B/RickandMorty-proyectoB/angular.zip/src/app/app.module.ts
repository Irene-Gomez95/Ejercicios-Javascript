import { NavFooterModule } from './components/nav-footer/nav-footer.module';
import { ListModule } from './list/list.module';
import { HomeModule } from './home/home.module';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeHeaderModule } from './components/home-header/home-header.module';

@NgModule({
  declarations: [
    AppComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HomeModule,
    ListModule,
    HomeHeaderModule,
    NavFooterModule
    
  ],

  bootstrap: [AppComponent]
})
export class AppModule { }
