import { FormsModule } from '@angular/forms'

import { NgModule } from '@angular/core'
import { CommonModule } from '@angular/common'
import { ListComponent } from './list.component'

@NgModule({
  declarations: [ListComponent],
  imports: [CommonModule, 
            FormsModule 
            ],

  exports: [ListComponent],
})
export class ListModule {}
