import { Injectable } from '@angular/core'
import { HttpClient } from '@angular/common/http'

@Injectable({
  providedIn: 'root',
})
export class CharacterService {
  getcharacters(): any {
    return this.http.get<any>(
      this.BASE_URL + `character`,
      {},
    )
  }
  private BASE_URL =
    'https://rickandmortyapi.com/api/';

  constructor(private http: HttpClient) {}

  characters() {
  /*   return this.http.get<any>(
      this.BASE_URL + `character`,
      {},
    ) */
  }

}
